import argparse
import re
import sys


def to_html(info_lines):
    section = 'undef'
    contents = 0
    txt = list()
    version = 'c48b2'

    line_count = 1

    for line in info_lines:
        line_count += 1

        substitutions = [
            (r'^\u001F$', ''),
            (r'^\S$', ''),
            (r'\201', ''),
            (r'\215', ''),
            (r'\217', ''),
            (r'\220', ''),
            (r'\235', ''),
            (r'&Atilde;&para;', '&ouml;'),
            (r'&acirc;&euro;&permil;', ''),
            (r'&acirc;&circ;&rsquo;', '-')
        ]

        for regex, replacement in substitutions:
            line = re.sub(regex, replacement, line)

        if line.startswith('CHARM'):
            txt.append('<!DOCTYPE html>')
            txt.append('<html>')
        elif re.search(r'File:\s+(.+)\s*[,-=]*\s+Node:\s+([A-Za-z ]+)', line):
            matches = re.search(r'File:\s+(.+)\s*[,-=]*\s+Node:\s+([A-Za-z ]+)',
                                line)
            node = matches.group(2)
            node = re.sub(' ', '', node)

            if re.search(r'\s*Top\s*', line):
                txt.append('<body>')
                txt.append('<pre>')

            if section != 'undef':
                txt.append('</div>')
                txt.append('<A NAME="' + node + '"></A>')
                txt.append('<div class="charmmdoc">')
                txt.append('<A HREF="#Top">Top</A>')
            else:
                txt.append('<A NAME="' + node + '"></A>')
                txt.append('<div class="charmmdoc">')

            section = node
            contents = 0
        elif (section != 'undef'
            and not re.search(r'\*\s*Menu:', line)
            and not re.search(r'Up:.+-=-\s*Previous:', line)
            and not re.search(r'Up:.+-=-\s*Next:', line)):
            if line:
                contents = 1

            line = re.sub(r'\*\s+(\S+)::\s+(\S+)',
                          r'* <A HREF="#\1">\1</A> | \2',
                          line)

            line = re.sub(r'\*\s+(\S+) (\S+)::\s+(\S+)',
                          r'* <A HREF="#\1\2">\1 \2</A> | \3',
                          line)

            line = re.sub(r'\*\s+(\S+) (\S+) (\S+)::\s+(\S+)',
                          r'* <A HREF="#\1\2\3">\1 \2 \3</A> | \4',
                          line)

            line = re.sub(r'\*\s+([\S ]+)\s*:+\s*\(doc\/(\S+)\.info\s*\)\s*\.*\s*',
                          r'* <A HREF="\2.html">\2</A>: ',
                          line)

            line = re.sub(r'\*\s+(\S+)\s*\s+\(doc\/(\S+)\.info\s*\)\s*\.*\s*',
                          r'* <A HREF="\2">\2</A>: ',
                          line)

            # line = re.compile(
            #     '([a-z])\s+\*[nN]ote\s+(\S+[^:]):*\s*\(doc\/(\S+)\.info\)[,\.]*\s*'
            # ).sub(
            #     '\1 <B>&raquo;</B> <A HREF="/documentation/version/' + version
            #     + '\3/">\3</A> DEBUG', line)
            # *note Minimiz:(doc/minimiz.info)

            line = re.sub(r'\*[nN]ote\s+(\S+[^:]):*\s*\(doc\/(\S+)\.info\)',
                          r'<A HREF="\2.html">\1</A>',
                          line)

            # line = re.sub(r'([a-z])\s+\*[nN]ote\s+(\S+[^:]):*\s*\(doc\/(\S+)\.info\)[,\.]*\s*',
            #               r'\1 <B>&raquo;</B> <A HREF="\3.html">\3</A> DEBUG1 ',
            #               line)

            # # *note Gete:(doc/usage.info)
            # line = re.sub(r'(?:[sS]ee)*\s*\*[nN]ote\s+(\S+[^:]):*\s*\(doc\/(\S+)\.info\)[,\.]*\s*',
            #               r'<B>&raquo;</B> <A HREF="\2.html">\2</A> DEBUG3 ',
            #               line)

            line = re.compile(r'(?:[sS]ee)*\s*\*[nN]ote\s+(\S+[^:]):*\s*\((\S+)\.info\)[,\.]*\s*').sub(r'&raquo; <A HREF="/documentation/version/' + version + '\2/">\2</A> ', line)
            line = re.compile(r'(?:[sS]ee)*\s*\*[nN]ote\s+(\S+[^:]):*\s*\((\S+)\)[,\.]*\s*').sub(r'&raquo; <A HREF="/documentation/version/' + version + '\2/">\2</A> ', line)
            line = re.compile(r'(?:[sS]ee)*\s*\*[nN]ote\s+(\S+[^:]):*\s*\(doc\/(\S+)\)[,\.]*\s*').sub(r'&raquo; <A HREF="/documentation/version/' + version + '\2/">\2</A> ', line)
            line = re.compile(r'(?:[sS]ee)*\s*\*[nN]ote\s+(.+[^:]):\s*\(doc\/(\S+)\.info\)[,\.]*\s*').sub(r'&raquo; <A HREF="/documentation/version/' + version + '\2/">\2</A> ', line)

            line = re.compile(r'see doc\/(\S+)\.info').sub(r'&raquo; <A HREF="/documentation/version/' + version + '\1/">\1</A> ', line)
            line = re.compile(r'[sS]ee\s+(\S+)\.info[,\.]*\s*').sub(r'&raquo; <A HREF="/documentation/version/' + version + '\1/">\1</A> ', line)
            line = re.compile(r'(?:the)*\s*\*\s+\S+ command:\s*\(doc\/(\S+)\.info\s*\)\s*\.*\s*').sub(r'&raquo; <A HREF="/documentation/version/' + version + '\1/">\1</A> ', line)
            line = re.compile(r'\S+:\s*\(doc\/(\S+)\.info\)\s*\.*').sub(r'&raquo; <A HREF="/documentation/version/' + version + '\1/">\1</A> ', line)
            line = re.compile(r'\(doc\/(\S+)\.info\)').sub(r'&raquo; <A HREF="/documentation/version/' + version + '\1/">\1</A> ', line)
            line = re.compile(r'\((\S+)\.info\)').sub(r'&raquo; <A HREF="/documentation/version/' + version + '\1/">\1</A> ', line)
            line = re.compile(r'Prerequisite reading:\s+(\S+)\.info').sub(r'Prerequisite reading: &raquo; <A HREF="/documentation/version/' + version + '\1/">\1</A> ', line)
            line = re.compile(r'(?:[sS]ee)\s+\*[nN]ote').sub('', line)
            line = re.compile(r'\* Info:\s+.Info..*').sub('', line)

            # if contents >= 1 and brcnt < 3:
            #     txt += line + "<BR>"
            if contents >= 1:
                txt.append(line)

    txt.append('</div></pre></body>')
    return txt


def main():
    parser = argparse.ArgumentParser(
                    prog='info2html.py',
                    description='converts CHARMM info docu files into html',
                    epilog='bottom of help')
    parser.add_argument('info_file_name')
    parser.add_argument('html_file_name')
    args = parser.parse_args()

    with open(args.info_file_name, 'r', encoding='latin-1') as info_file:
        html = to_html(info_file.readlines())

    with open(args.html_file_name, 'w') as html_file:
        html_file.writelines(html)


if __name__ == "__main__":
    main()
