"""Change the size of CHARMM's fixed storage

Corresponds to CHARMM command `DIMENSion`

See CHARMM documentation [dimens](<https://academiccharmm.org/documentation/version/latest/dimens>)
for more information

Examples
========
>>> import pycharmm_init

`dimens chsize 500000`
>>> pycharmm_init.dimens.set_chsize(500000)

The dimensions must be changed prior to importing pycharmm.
>>> import pycharmm
>>> import pycharmm.lib

Printing out the current dimensions may be done at any time.
`dimens`
>>> pycharmm_init.dimens.show(pycharmm.lib.charmm)


"""

import copy
import ctypes


class Dim:
    _value : int
    _changed : bool

    def __init__(self, default=1):
        """a utility class to store a single size for a dimens array of charmm

        Parameters
        ----------
        default : int
            A nonzero positive integer, the default size for a dimens array
        """
        self._validate_value(default)
        self._value = default
        self._changed = False

    def set(self, new_value: int) -> int:
        """set the value of this particular Dim

        Parameters
        ----------
        new_value : int
            a nonzero positive integer, a new size for the dimens array

        Returns
        -------
        old_value : integer
            previous size for the dimens array
        """
        self._validate_value(new_value)
        old_value = self._value
        if (new_value != old_value):
            self._value = new_value
            self._changed = True

        return old_value

    def get(self) -> int:
        """get the current value of this particular Dim

        Returns
        -------
        val : integer
            a copy of the current size for this dimens array
        """
        val = copy.deepcopy(self._value)
        return val

    def has_changed(self) -> bool:
        """Has this Dim every had its value set after initialization?

        Returns
        -------
        q : bool
            True if changed after init, False otherwise
        """
        q = copy.deepcopy(self._changed)
        return q

    def _validate_value(self, new_value):
        if not (isinstance(new_value, int) and (new_value > 0)):
            raise ValueError("Dim default value must be " +
                             " an integer greater than zero.")

        return new_value


class Dimens:
    _chsize : Dim
    _maxa : Dim
    _maxb : Dim
    _maxt : Dim
    _maxp : Dim
    _maximp : Dim
    _maxnb : Dim
    _maxpad : Dim
    _maxres : Dim
    _maxseg : Dim
    _maxcrt : Dim
    _maxshk : Dim
    _maxaim : Dim
    _maxgrp : Dim
    _maxnbf : Dim
    _maxitc : Dim

    def __init__(self):
        """a utility class to store sizes for dimens arrays of charmm

        A Dimens object must be created and manipulated before pycharmm or
        any submodule is imported. After pycharmm is imported a Dimens object
        will have no affect on charmm whatsoever.
        """
        default_chsize = 360720
        self._chsize = Dim(default_chsize)
        self._maxa = Dim(default_chsize)
        self._maxb = Dim(default_chsize)
        self._maxt = Dim(2 * default_chsize)
        self._maxp = Dim(3 * default_chsize)
        self._maximp = Dim(default_chsize // 2)
        self._maxnb = Dim(default_chsize // 4)
        self._maxpad = Dim(default_chsize)
        self._maxres = Dim(default_chsize // 3)
        self._maxseg = Dim(default_chsize // 8)
        self._maxcrt = Dim(default_chsize // 3)
        self._maxshk = Dim(default_chsize)
        self._maxaim = Dim(2 * default_chsize)
        self._maxgrp = Dim(2 * default_chsize // 3)
        self._maxnbf = Dim(default_chsize // 360)
        self._maxitc = Dim(default_chsize // 360)

    def set_chsize(self, new_value) -> int:
        """set the max number of atoms in charmm

        After communicate_dimens is called, this will also update the size of
        most other dimens arrays which will not be reflected in
        the Dimens object.

        Parameters
        ----------
        new_value : int
            a nonzero positive integer, a new size for the dimens array

        Returns
        -------
        old_value : integer
            previous size for the dimens array
        """
        old_value = self._chsize.set(new_value)
        return old_value

    def set_maxa(self, new_value) -> int:
        """set only the max number of atoms in charmm

        Parameters
        ----------
        new_value : int
            a nonzero positive integer, a new size for the dimens array

        Returns
        -------
        old_value : integer
            previous size for the dimens array
        """
        old_value = self._maxa.set(new_value)
        return old_value

    def set_maxb(self, new_value) -> int:
        """set the max number of bonds in charmm

        Parameters
        ----------
        new_value : int
            a nonzero positive integer, a new size for the dimens array

        Returns
        -------
        old_value : integer
            previous size for the dimens array
        """
        old_value = self._maxb.set(new_value)
        return old_value

    def set_maxt(self, new_value) -> int:
        """set the max number of angles (thetas) in charmm

        Parameters
        ----------
        new_value : int
            a nonzero positive integer, a new size for the dimens array

        Returns
        -------
        old_value : integer
            previous size for the dimens array
        """
        old_value = self._maxt.set(new_value)
        return old_value

    def set_maxp(self, new_value) -> int:
        """set the max number of dihedrals (phis) in charmm

        Parameters
        ----------
        new_value : int
            a nonzero positive integer, a new size for the dimens array

        Returns
        -------
        old_value : integer
            previous size for the dimens array
        """
        old_value = self._maxp.set(new_value)
        return old_value

    def set_maximp(self, new_value) -> int:
        """set the max number of improper dihedrals in charmm

        Parameters
        ----------
        new_value : int
            a nonzero positive integer, a new size for the dimens array

        Returns
        -------
        old_value : integer
            previous size for the dimens array
        """
        old_value = self._maximp.set(new_value)
        return old_value

    def set_maxnb(self, new_value) -> int:
        """set the max number of explicit nonbond exclusions in charmm

        Parameters
        ----------
        new_value : int
            a nonzero positive integer, a new size for the dimens array

        Returns
        -------
        old_value : integer
            previous size for the dimens array
        """
        old_value = self._maxnb.set(new_value)
        return old_value

    def set_maxpad(self, new_value) -> int:
        """set the max number of donors or acceptors in charmm

        Parameters
        ----------
        new_value : int
            a nonzero positive integer, a new size for the dimens array

        Returns
        -------
        old_value : integer
            previous size for the dimens array
        """
        old_value = self._maxpad.set(new_value)
        return old_value

    def set_maxres(self, new_value) -> int:
        """set the max number of residues in charmm

        Parameters
        ----------
        new_value : int
            a nonzero positive integer, a new size for the dimens array

        Returns
        -------
        old_value : integer
            previous size for the dimens array
        """
        old_value = self._maxres.set(new_value)
        return old_value

    def set_maxseg(self, new_value) -> int:
        """set the max number of segments in charmm

        Parameters
        ----------
        new_value : int
            a nonzero positive integer, a new size for the dimens array

        Returns
        -------
        old_value : integer
            previous size for the dimens array
        """
        old_value = self._maxseg.set(new_value)
        return old_value

    def set_maxcrt(self, new_value) -> int:
        """set the max number of cross terms in charmm

        Parameters
        ----------
        new_value : int
            a nonzero positive integer, a new size for the dimens array

        Returns
        -------
        old_value : integer
            previous size for the dimens array
        """
        old_value = self._maxcrt.set(new_value)
        return old_value

    def set_maxshk(self, new_value) -> int:
        """set the max number of SHAKE constraints in charmm

        Parameters
        ----------
        new_value : int
            a nonzero positive integer, a new size for the dimens array

        Returns
        -------
        old_value : integer
            previous size for the dimens array
        """
        old_value = self._maxshk.set(new_value)
        return old_value

    def set_maxaim(self, new_value) -> int:
        """set the max number of atoms including image atoms in charmm

        Parameters
        ----------
        new_value : int
            a nonzero positive integer, a new size for the dimens array

        Returns
        -------
        old_value : integer
            previous size for the dimens array
        """
        old_value = self._maxaim.set(new_value)
        return old_value

    def set_maxgrp(self, new_value) -> int:
        """set the max number of groups in charmm

        Parameters
        ----------
        new_value : int
            a nonzero positive integer, a new size for the dimens array

        Returns
        -------
        old_value : integer
            previous size for the dimens array
        """
        old_value = self._maxgrp.set(new_value)
        return old_value

    def set_maxnbf(self, new_value) -> int:
        """set the max number of nonbond fixes (VdW). in charmm

        Parameters
        ----------
        new_value : int
            a nonzero positive integer, a new size for the dimens array

        Returns
        -------
        old_value : integer
            previous size for the dimens array
        """
        old_value = self._maxnbf.set(new_value)
        return old_value

    def set_maxitc(self, new_value) -> int:
        """set the max number of atom types in charmm

        Parameters
        ----------
        new_value : int
            a nonzero positive integer, a new size for the dimens array

        Returns
        -------
        old_value : integer
            previous size for the dimens array
        """
        old_value = self._maxitc.set(new_value)
        return old_value

    def communicate_dimens(self, lib):
        """send any changed sizes to the charmm shared library

        This will be called in the init method of the CharmmLib class.
        Once the library is initialized, updating dimens will not be
        possible.

        Parameters
        ----------
        lib :
            a charmm shared library created using ctypes
            This charmm will have its dimens updated.
        """
        if self._chsize.has_changed():
            new_dim = ctypes.c_int(self._chsize.get())
            lib.dimens_set_chsize(ctypes.byref(new_dim))

        if self._maxa.has_changed():
            new_dim = ctypes.c_int(self._maxa.get())
            lib.dimens_set_maxa(ctypes.byref(new_dim))

        if self._maxb.has_changed():
            new_dim = ctypes.c_int(self._maxb.get())
            lib.dimens_set_maxb(ctypes.byref(new_dim))

        if self._maxt.has_changed():
            new_dim = ctypes.c_int(self._maxt.get())
            lib.dimens_set_maxt(ctypes.byref(new_dim))

        if self._maxp.has_changed():
            new_dim = ctypes.c_int(self._maxp.get())
            lib.dimens_set_maxp(ctypes.byref(new_dim))

        if self._maximp.has_changed():
            new_dim = ctypes.c_int(self._maximp.get())
            lib.dimens_set_maximp(ctypes.byref(new_dim))

        if self._maxnb.has_changed():
            new_dim = ctypes.c_int(self._maxnb.get())
            lib.dimens_set_maxnb(ctypes.byref(new_dim))

        if self._maxpad.has_changed():
            new_dim = ctypes.c_int(self._maxpad.get())
            lib.dimens_set_maxpad(ctypes.byref(new_dim))

        if self._maxres.has_changed():
            new_dim = ctypes.c_int(self._maxres.get())
            lib.dimens_set_maxres(ctypes.byref(new_dim))

        if self._maxseg.has_changed():
            new_dim = ctypes.c_int(self._maxseg.get())
            lib.dimens_set_maxseg(ctypes.byref(new_dim))

        if self._maxcrt.has_changed():
            new_dim = ctypes.c_int(self._maxcrt.get())
            lib.dimens_set_maxcrt(ctypes.byref(new_dim))

        if self._maxshk.has_changed():
            new_dim = ctypes.c_int(self._maxshk.get())
            lib.dimens_set_maxshk(ctypes.byref(new_dim))

        if self._maxaim.has_changed():
            new_dim = ctypes.c_int(self._maxaim.get())
            lib.dimens_set_maxaim(ctypes.byref(new_dim))

        if self._maxgrp.has_changed():
            new_dim = ctypes.c_int(self._maxgrp.get())
            lib.dimens_set_maxgrp(ctypes.byref(new_dim))

        if self._maxnbf.has_changed():
            new_dim = ctypes.c_int(self._maxnbf.get())
            lib.dimens_set_maxnbf(ctypes.byref(new_dim))

        if self._maxitc.has_changed():
            new_dim = ctypes.c_int(self._maxitc.get())
            lib.dimens_set_maxitc(ctypes.byref(new_dim))

    def show(self, lib):
        """print out the sizes of all the dimens arrays from charmm
        """
        lib.dimens_print()


dimens = Dimens()
