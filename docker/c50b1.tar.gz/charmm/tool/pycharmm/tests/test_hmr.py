# This script tests the hmr function from pycharmm
#  copyright C.L. Brooks III, February 17, 2025

import os
import sys
import subprocess
import shlex



try:
    charmm_data_dir = os.environ['CHARMM_DATA_DIR']
except KeyError:
    print('please set environment variable CHARMM_DATA_DIR', file=sys.stderr)
    sys.exit(1)


from pycharmm import *


read.rtf('toppar/top_all36_prot.rtf')

prm_fn = charmm_data_dir + '/par_all36_prot.prm'
read.prm('toppar/par_all36_prot.prm', flex=True)

old_warn_level = settings.set_warn_level(-1)
old_bomb_level = settings.set_bomb_level(-1)

read.stream('toppar/toppar_water_ions.str')

settings.set_warn_level(old_warn_level)
settings.set_bomb_level(old_bomb_level)
# end toppar/toppar_water_ions.str

# read in the sequence of the protein to be generated
# only useful for the same residue
read.sequence_string('ALA')

gen.new_segment('ADP', 'ACE', 'CT3', setup_ic=True)

ic.prm_fill(False)
ic.seed(1, 'CAY', 1, 'CY', 1, 'N')
ic.build()

# The coor orie command is useful to expose since it allows one to
# orient the system in preparation for other calculations
coor.orient(by_rms=False,by_mass=False,by_noro=False)
coor.show()

# The nbonds command is where most of the control of how the
# energy is calculated to compute forces for minimization, dynamics
# or simply energy commands, this should be exposed to the pyCHARMM
# interface so that one can set-up exactly how the forces/energy is
# calculated.

my_nbonds = NonBondedScript(
    cutnb=18.0, ctonnb=15.0, ctofnb=13.0,
    eps=1.0,
    cdie=True,
    atom=True, vatom=True,
    fswitch=True, vfswitch=True)
my_nbonds.run()

# Exposing the minimizer is helpful since it will be a widely
# useful function. Note that if nbonds is available to the PyCHARMM API
# then this sort of basic minimize command is sufficient, where abnr could
# be substituted by sd or conj as well.
#
# minimize abnr nstep 1000 tole 1e-3 tolgr 1e-3
minimize.run_abnr(nstep=1000, tolenr=1e-3, tolgrd=1e-3)
energy.show()

# Here it would be useful to have the coordinates available
# to the python script with the full precision by directly accessing
# the coordinate arrays in source/ltm/coord_ltm.F90
# and coordc_ltm.F90 (comparison coordinates).
coor.show()
write.coor_pdb('adp.pdb')
convpdb_command = 'convpdb.pl'
convpdb_str = (convpdb_command + ' -solvate -cutoff 10 -cubic -out charmm22 ' +
               'adp.pdb')
p1 = subprocess.Popen(shlex.split(convpdb_str), stdout=subprocess.PIPE)

convpdb_str = convpdb_command + ' -segnames -nsel TIP3'
wt00_pdb_fn = 'wt00.pdb'
with open(wt00_pdb_fn, 'w') as wt00_pdb_file:
    p2 = subprocess.Popen(shlex.split(convpdb_str),
                          stdin=p1.stdout, stdout=wt00_pdb_file)

p2.communicate()

# Here is an alternative means of reading a sequence
# read sequ pdb name pdb/wt00.pdb
read.sequence_pdb(wt00_pdb_fn)

# Another example of the generate command
# generate wt00 noangle nodihedral
# TODO: add no_angle, no_dihedral opts
gen.new_segment('WT00', angle=False, dihedral=False)

read.pdb(wt00_pdb_fn, resid=True)

# This command gives info that is useful in setting up
# simulation though could be gotten in separate CHARMM
# preparation.
# coor stat
stats = coor.stat()

xsize = stats['xmax'] - stats['xmin']
ysize = stats['ymax'] - stats['ymin']
zsize = stats['zmax'] - stats['zmin']

boxsize = max(xsize, ysize, zsize)
boxhalf = boxsize / 2.0

old_masses = psf.get_amass()

psf.hmr()

new_masses = psf.get_amass()

import numpy as np

if abs(np.sum(old_masses)-np.sum(new_masses)) <= 1e-5:
    print('****HMR TEST PASSED****')

# Clean up
os.system('rm adp.pdb wt00.pdb')
