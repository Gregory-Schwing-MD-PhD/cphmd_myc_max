import pycharmm_init


pycharmm_init.dimens.set_chsize(500000)


import pycharmm
import pycharmm.lib


pycharmm_init.dimens.show(pycharmm.lib.charmm)
