import argparse
import os

def create_header():
    return """
        <!DOCTYPE html>
        <html>
        <head>
            <title>CHARMM documentation index</title>
        </head>
        <body>
    """


def create_footer():
    return """
        </body>
        </html>
    """


def create_pycharmm_index():
    return """
        <h1>pycharmm documentation</h1>
        <ul>
            <li><a href="pycharmm.html">about pycharmm</a></li>
            <li><a href="pycharmm_index.html">pycharmm python api</a></li>
        </ul>
    """


def create_charmm_script_index(files):
    # Start writing the HTML content
    html_content = """
        <h1>CHARMM script index</h1>
        <ul>
    """

    for filename in sorted(files):
        html_content += '  <li><a href="{0}">{0}</a></li>\n'.format(filename)

    html_content += '</ul>'
    return html_content


# create_html_index("/path/to/your/directory")
def main():
    parser = argparse.ArgumentParser(
                    prog='index.py',
                    description='creates index based on directory listing',
                    epilog='bottom of help')
    parser.add_argument('dir_to_index',
                        help='directory of info files to index')
    parser.add_argument('path_to_index',
                        help='directory where index.html will be written')
    parser.add_argument('-p', '--pycharmm', action='store_true',
                        help='link to pycharmm docu in index output')
    args = parser.parse_args()

    html = create_header()
    if args.pycharmm:
        html += create_pycharmm_index()

    # Get the list of files (not directories) in the directory
    files = [os.path.basename(f) for f in os.listdir(args.dir_to_index)
             if (os.path.isfile(os.path.join(args.dir_to_index, f))
                                and f.endswith('.info'))]

    files = [f[:-5] + '.html' for f in files]

    html += create_charmm_script_index(files)
    html += create_footer()

    index_path = os.path.join(args.path_to_index, 'index.html')
    with open(index_path, 'w') as html_file:
        html_file.write(html)


if __name__ == "__main__":
    main()
