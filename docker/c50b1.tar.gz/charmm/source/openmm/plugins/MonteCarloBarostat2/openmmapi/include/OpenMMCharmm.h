#ifndef OPENMM_CHARMM_H_
#define OPENMM_CHARMM_H_

#include "openmm/MonteCarloBarostat2.h"

#endif

