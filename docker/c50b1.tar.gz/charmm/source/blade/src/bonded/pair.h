#ifndef BONDED_PAIR_H
#define BONDED_PAIR_H

// Forward definitions
class System;

void getforce_nb14(System *system,bool calcEnergy);
void getforce_nbex(System *system,bool calcEnergy);

#endif
