#ifndef HOLONOMIC_RECTIFY_H
#define HOLONOMIC_RECTIFY_H

#include "main/defines.h"



// Forward definitions
class System;

void holonomic_rectify(System *system);
void holonomic_rectifyback(System *system);

#endif
